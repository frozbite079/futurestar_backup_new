from django.apps import AppConfig


class FuturestarAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'FutureStar_App'
